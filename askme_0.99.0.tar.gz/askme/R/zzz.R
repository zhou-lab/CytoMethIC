#' @import utils
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Loading askme.")
}
