## ---- message=FALSE, warning=FALSE--------------------------------------------
library(askme)

## ----result="asis", echo=FALSE------------------------------------------------
library(knitr)
kable(askme_models[, c("ModelID", "PredictionLabelDescription")],
  caption = "AskMe supported models"
)

## ----message=FALSE------------------------------------------------------------
library(tibble)
library(sesameData)
betas <- sesameDataGet("HM450.1.TCGA.PAAD")$betas
askme_classify(betas, m_cancertype_CNS66)

## -----------------------------------------------------------------------------
sessionInfo()

